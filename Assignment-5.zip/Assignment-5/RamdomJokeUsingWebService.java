import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;

import java.net.URL;
import java.nio.charset.Charset;

/**
 * Created by scispl20 on 12-04-2017.
 * This class is created for generating random Joke every time
 * through JSON String from Web Service and parsing the
 * JSON Object for printing the random joke on console
 *@author scispl20
 */
public class RamdomJokeUsingWebService
{
    /**
     * This function is used for Reading JSON String from URL
     * and return it for reading the same String
     * @param url
     * @return json String
     * @throws IOException
     * @throws JSONException
     */
    public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException
    {
        InputStream is = new URL(url).openStream();
        try {

            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);
            return json;
        } finally {
            is.close();
        }
    }

    /**
     * This function is called by readJsonFromUrl() to
     * read the JSON contend
     * @param rd as object og BufferedReader
     * @return
     * @throws IOException
     */
    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    public static void main(String[] args) throws IOException, JSONException
    {
        JSONObject json = readJsonFromUrl("http://tambal.azurewebsites.net/joke/random");
        String jokes = (String) json.get("joke");
        System.out.println("Ramdom joke generated througn json String :- "+jokes);

        //System.out.println("****************");
       // System.out.println(json.toString());
    }
}
