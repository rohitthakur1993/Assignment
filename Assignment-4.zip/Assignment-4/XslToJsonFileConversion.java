
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.json.simple.JSONObject;

import java.io.*;
import java.util.*;

/**
 * Created by scispl20 on 11-04-2017.
 * This class is created for reading input.xsl file
 * and convert it into Employees.json file using an
 * POJO class Employee.java
 * input: input.xsl
 * output: Employees.json
 * The class uses data structures List and Map
 */
public class XslToJsonFileConversion
{

    /**
     * This function is used to read the excel file
     * and convert it into List of object
     * input: input.xsl
     * output: List of Employees Object
     * @return List
     * @throws java.io.FileNotFoundException
     */

    @SuppressWarnings("deprecation")
    public List<Employee> readXSLFileIntoEmployeeObject()
    {
        List<Employee> arrayList= new ArrayList<Employee>();
        PrintWriter pw1 = null;
        try
        {
            FileInputStream file = new FileInputStream(new File("C:/Users/scispl20/Downloads/assignment-4/input.xls"));
            @SuppressWarnings("resource")
            HSSFWorkbook workbook = new HSSFWorkbook(file);
            HSSFSheet sheet = workbook.getSheetAt(0);
            ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
            Iterator<Row> rowIterator = sheet.iterator();
            Employee [] e1=new Employee[13];

            while (rowIterator.hasNext())
            {
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                ArrayList<String> rowData = new ArrayList<String>();

                Cell cell = cellIterator.next();
                e1[cell.getRowIndex()]=new Employee();

                e1[cell.getRowIndex()].setEmployeeID(cell.getRow().getCell(0).toString());
                e1[cell.getRowIndex()].setEmployeeName(cell.getRow().getCell(1).toString());
                e1[cell.getRowIndex()].setCity(cell.getRow().getCell(3).toString());
                e1[cell.getRowIndex()].setDepartment(cell.getRow().getCell(2).toString());
                e1[cell.getRowIndex()].setDesignation(cell.getRow().getCell(4).toString());
            }

            file.close();
            System.out.println("Input.xsl read successfully");
            for(int i= 1;i<13;i++)
            {
                arrayList.add(e1[i]);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return(arrayList);
    }

    /**
     * This function is used to convert the List into Json Object
     * And write Json object to Json file
     * input: List of Employees Object
     * output: Employees.json File
     * @param list
     * @throws java.io.FileNotFoundException
     */

    public void convertListIntoJsonFile(List list)
    {
        Map<String,List> map= new HashMap<String, List>();
        try
        {
           map.put("employees",list);
           JSONObject json1=new JSONObject(map);
           ObjectMapper mapper = new ObjectMapper();
           mapper.writeValue(new File("C:/Users/scispl20/Downloads/assignment-4/Employees.json"), json1);
           System.out.println("Converted into Employees.json Successfully");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {
        XslToJsonFileConversion xsl=new XslToJsonFileConversion();

        List list=xsl.readXSLFileIntoEmployeeObject();
        xsl.convertListIntoJsonFile(list);
    }
}

