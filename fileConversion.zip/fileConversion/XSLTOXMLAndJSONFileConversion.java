package fileConversion;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.json.JSONException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;


/**
 * This class is used to read excel file and convert it into 
 * XML file format and JSON file format 
 * @param input : excel file
 * @param output: XML file, JSON file
 * Throws IOException,FileNotFoundException
 * @author scispl20
 *
 */

public class XSLTOXMLAndJSONFileConversion {

	/**
	 * This function is used to read the excel file and parse into XML file
	 * @param takes input as excel input.xsl file
	 * @param generates output as XML file employee.xml
	 * Handles IOException, FileNotFoundException, ParserConfigurationException,TransformerConfigurationException 
	 */
	
	InputStream inputStream = null;
    String xlsPath ="C:/Users/scispl20/Downloads/assignment-3/input.xls";

	
	@SuppressWarnings("deprecation")
	public void convertXSLToXML()
	{
	    InputStream inputStream = null;
	    String xlsPath ="C:/Users/scispl20/Downloads/assignment-3/input.xls";
	    try
	    {
	        inputStream = new FileInputStream (xlsPath);
	    }
	    catch (FileNotFoundException e)
	    {
	        System.out.println ("File not found in the specified path.");
	        e.printStackTrace ();
	    }
	    
	    
	    POIFSFileSystem fileSystem = null;

	    try {
	        
	        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
	        Document document = builder.newDocument();
	        Element rootElement = document.createElement("employees");
	        document.appendChild(rootElement);
	        fileSystem = new POIFSFileSystem (inputStream);
	        
	        @SuppressWarnings("resource")
			HSSFWorkbook      workBook = new HSSFWorkbook (fileSystem);
	        HSSFSheet         sheet    = workBook.getSheetAt (0); 
	        Iterator<?> rows     = sheet.rowIterator ();

	        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
	        while (rows.hasNext ()) 
	        {
	            HSSFRow row = (HSSFRow) rows.next(); 

	            Iterator<?> cells = row.cellIterator (); 

	            ArrayList<String> rowData = new ArrayList<String>();
	            while (cells.hasNext ())
	            {
	                HSSFCell cell = (HSSFCell) cells.next ();

	                switch (cell.getCellType ())
	                {
	                case HSSFCell.CELL_TYPE_NUMERIC :
	                {
	                    //System.out.println ("Numeric: " + cell.getNumericCellValue ());
	                    rowData.add(cell.getNumericCellValue () + "");
	                    break;
	                }
	                case HSSFCell.CELL_TYPE_STRING :

	                {
	                    
	                    HSSFRichTextString richTextString = cell.getRichStringCellValue ();


	                    rowData.add(richTextString.getString ());
	                    break;
	                }
	                default:
	                {
	                   
	                    System.out.println ("Type not supported.");
	                    break;
	                }
	                } 

	            } 
	            data.add(rowData);
	            
	        } 

	        int numOfProduct = data.size();

	        for (int i = 1; i < numOfProduct; i++){
	            Element productElement = document.createElement("employee");
	            rootElement.appendChild(productElement);

	            int index = 0;
	            for(String s: data.get(i)) {
	                String headerString = data.get(0).get(index);
	                if( data.get(0).get(index).equals("image link") ){
	                    headerString = "image_link";
	                }

	                if( data.get(0).get(index).equals("product type") ){
	                    headerString = "product_type";
	                }

	                Element headerElement = document.createElement(headerString);
	                productElement.appendChild(headerElement);
	                headerElement.appendChild(document.createTextNode(s));
	                index++;
	            }
	        }

	        TransformerFactory tFactory = TransformerFactory.newInstance();

	        Transformer transformer = tFactory.newTransformer();
	        //Add indentation to output
	        transformer.setOutputProperty
	        (OutputKeys.INDENT, "yes");
	        transformer.setOutputProperty(
	                "{http://xml.apache.org/xslt}indent-amount", "2");

	        DOMSource source = new DOMSource(document);
	        StreamResult result = new StreamResult(new File("C:/Users/scispl20/Downloads/assignment-3/employee.xml"));
	        //StreamResult result = new StreamResult(System.out);
	        transformer.transform(source, result);
	        System.out.println("Input.xsl parsed into employee.xml");

	    }
	    catch(IOException e)
	    {
	        System.out.println("IOException " + e.getMessage());
	    } catch (ParserConfigurationException e) {
	        System.out.println("ParserConfigurationException " + e.getMessage());
	    } catch (TransformerConfigurationException e) {
	        System.out.println("TransformerConfigurationException "+ e.getMessage());
	    } catch (TransformerException e) {
	        System.out.println("TransformerException " + e.getMessage());
	    }
	}
	
	/**
	 * This function is used to read the excel file and parse into JSON file
	 * @param takes input as excel input.xsl file
	 * @param generates output as XML file employee.xml
	 * @return 
	 * @throws IOException 
	 * @throws InvalidFormatException 
	 * @throws EncryptedDocumentException 
	 * @throws JSONException 
	 */
	
	@SuppressWarnings("deprecation")
	public void convertXSLToJSON(String sourceFileName,String destinationFileName)
	{
	    PrintWriter pw1 = null; 
		try
		{
	    	  pw1 =  new PrintWriter(new FileWriter( destinationFileName ));
	          pw1.println("{");
	          pw1.println("\t employees  : [ ");
	    
			FileInputStream file = new FileInputStream(new File("C:/Users/scispl20/Downloads/assignment-3/input.xls"));
		    FileOutputStream out = 
						new FileOutputStream(new File("C:/Users/scispl20/Downloads/assignment-3/output51.txt"));
			 
			@SuppressWarnings("resource")
			HSSFWorkbook workbook = new HSSFWorkbook(file);

			HSSFSheet sheet = workbook.getSheetAt(0);
			ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
	        Iterator<Row> rowIterator = sheet.iterator();
	        while (rowIterator.hasNext()) 
	        {
	            Row row = rowIterator.next();
	                //For each row, iterate through all the columns
	            Iterator<Cell> cellIterator = row.cellIterator();
	            ArrayList<String> rowData = new ArrayList<String>();
	         
	            	 pw1.println("\t\t\t{  ");
	                 Cell cell = cellIterator.next();
	                 pw1.println("\t\t\t"+" \"id\"" + " : \t\""+cell.getRow().getCell(0)+ "\" ,");
	                 pw1.println("\t\t\t"+" \"name\""+" : \t\""+cell.getRow().getCell(1)+ "\" ,");
                     pw1.println("\t\t\t"+"\"department\"" + " : \t\""+cell.getRow().getCell(2)+ "\" ,");
                     pw1.println("\t\t\t"+"\"city\""+": \t\""+cell.getRow().getCell(3)+"\",");
                     pw1.println("\t\t\t\"designation\" : \t\""+cell.getRow().getCell(4)+ "\" ,");
                     pw1.println("\t\t\t},");															
	
	                 switch (cell.getCellType()) 
	                 {
	                        case Cell.CELL_TYPE_NUMERIC:
	                        {
	                    
	                            workbook.write(out);
	                            
	                            break;
	                 		}
	                        case Cell.CELL_TYPE_STRING:
	                        {
	                        	@SuppressWarnings("unused")
								HSSFRichTextString richTextString = (HSSFRichTextString) cell.getRichStringCellValue ();
	                            workbook.write(out);
	                            break;
	                        }
	             }
	            data.add(rowData);
	        }
	        pw1.println("\t\t \t  }...  ");
	          pw1.println("\t \t\t\t   ] ");
	          pw1.println("}");
	          pw1.close();
	        
	        file.close();
	        System.out.println("Input.xsl parsed into Employees.json");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws TransformerConfigurationException, ParserConfigurationException, SAXException, EncryptedDocumentException, InvalidFormatException, IOException, JSONException {
		
		String sourceFileName = "C:/Users/scispl20/Downloads/assignment-3/input.xsl";
		String destinationFileName = "C:/Users/scispl20/Downloads/assignment-3/Employees1.json";
		
		XSLTOXMLAndJSONFileConversion xsl=new XSLTOXMLAndJSONFileConversion();
		
		xsl.convertXSLToXML ();
		
		xsl.convertXSLToJSON(sourceFileName, destinationFileName);
	
	}
		
}
