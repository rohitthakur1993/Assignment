package fileConversion;

import java.io.File;
import java.io.IOException; 

import org.codehaus.jackson.map.ObjectMapper; 

import fileConversion.Employee;

public class JsonToObject {

public static void main(String a[]){

    ObjectMapper mapper = new ObjectMapper();
    try {
        File jsonInputFile = new File("C:/Users/scispl20/Downloads/assignment-3/output5.txt");
        Employee emp = mapper.readValue(jsonInputFile, Employee.class);
        System.out.println(emp);

    } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
  }
}

