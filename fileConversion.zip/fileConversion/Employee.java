package fileConversion;

public class Employee {

	private int employeeID;
    private String employeeName;
    private String department;
    private String city;
    private String designation;
    
    
	@Override
	public String toString(){
	    StringBuilder sb = new StringBuilder();
	    sb.append("************************************");
	    sb.append("\nemployeeId: ").append(employeeID);
	    sb.append("\nemployeeName: ").append(employeeName);
	    sb.append("\ndesignation: ").append(designation);
	    sb.append("\ndepartment: ").append(department);
	    sb.append("\ncity: ").append(city);
	    sb.append("\n************************************");
	    return sb.toString();
	}

	
	public Employee(int employeeID, String employeeName, String department,
			String city, String designation) {
		//super();
		this.employeeID = employeeID;
		this.employeeName = employeeName;
		this.department = department;
		this.city = city;
		this.designation = designation;
	}
//	*/

	public int getEmployeeID() {
		return employeeID;
	}


	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}
    
    
    
}
