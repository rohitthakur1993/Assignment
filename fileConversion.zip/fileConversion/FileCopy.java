package fileConversion;

import fileConversion.Employee;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileCopy {

  public static void main(String[] args){
	  String sourceFileName = "C:/Users/scispl20/Downloads/assignment-3/output5.txt";
	  String destinationFileName = "C:/Users/scispl20/Downloads/assignment-3/json2.txt";
	  copyFile(sourceFileName, destinationFileName);
  }	

  
 private static void copyFile(String sourceFileName,String destinationFileName)
 { 

      BufferedReader br = null;
      PrintWriter pw = null; 

      int i=0;
      
      try {
          br = new BufferedReader(new FileReader( sourceFileName ));
    	  pw =  new PrintWriter(new FileWriter( destinationFileName ));

          String line;
          pw.println("{");
          pw.println("\t employees  : [ ");
          pw.println("\t\t   {  ");
          
          while ((line = br.readLine()) != null ) 
          {
        	  
        	  
        	  String[] words = line.split("\t");
        	  pw.println("\t\t\t id : \t"+words[0]);
  	  
        	  pw.println("\t\t\t name : \t"+words[1]);
    
        	  pw.println("\t\t\t department : \t"+words[2]);
        	
        	  pw.println("\t\t\t city :\t"+words[3]);
        
        	  pw.println("\t\t\t designation : \t"+words[4]);
        	  pw.println("\t\t\t },");
        	  pw.println("\t\t\t {");
        	
        	

          pw.println("\t\t   }...  ");
          pw.println("\t  ] ");
          pw.println("}");
          br.close();
          pw.close();
          }
      }catch (Exception e) {
	  e.printStackTrace();
      }
}
}