package fileConversion;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class XSLToMap {
	
	String filePath ="C:/Users/scispl20/Downloads/assignment-3/input.xls";
	
	
    @SuppressWarnings("deprecation")
	public Map<Integer, String> getKnownGoodMap(String filePath) {
        int key = 0;
        String value = "";

        Map<Integer ,String> knownGoodMap = new LinkedHashMap<Integer ,String>();
        try {

            FileInputStream file = new FileInputStream(new File(filePath));

            @SuppressWarnings("resource")
			HSSFWorkbook workbook = new HSSFWorkbook(file);

            HSSFSheet sheet = workbook.getSheetAt(0);

            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    switch (cell.getCellType())
                    {
                    
                    	case Cell.CELL_TYPE_NUMERIC:
                    		key = (int) cell.getNumericCellValue();
                    		break;
                    	case Cell.CELL_TYPE_STRING:
                    		value = cell.getStringCellValue();
                    		break;
                    }

                   /* if (key != null  && value != Integer.MIN_VALUE) {
                        knownGoodMap.put(key, value);
                        key = null;
                        value = Integer.MIN_VALUE;
                    */
                    
                    if (key!= Integer.MIN_VALUE  && value != null) {
                        knownGoodMap.put(key, value);
                        key = Integer.MIN_VALUE;
                        value = null;
                    }
                }
            }
            file.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return knownGoodMap;
    }
    public static void main(String[] args) {
    	XSLToMap details = new XSLToMap();
        System.out.println("Method Details : "+details.getKnownGoodMap("C:/Users/scispl20/Downloads/assignment-3/input.xls"));
    }
}